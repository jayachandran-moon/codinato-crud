<?php

// Handle OTP verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_otp'])) {
    $submitted_otp = filter_var($_POST['otp_input'], FILTER_SANITIZE_STRING);
    
    if (!isset($_SESSION['otp_data'])) {
        $_SESSION['error'] = "No OTP found. Please request a new OTP.";
    } else {
        $otp_data = $_SESSION['otp_data'];
        
        // Check if OTP is expired
        if (strtotime($otp_data['expires_at']) < time()) {
            $_SESSION['error'] = "OTP has expired. Please request a new one.";
            unset($_SESSION['otp_data']);
        } 
        // Check if too many attempts
        elseif ($otp_data['attempts'] >= 3) {
            $_SESSION['error'] = "Too many failed attempts. Please request a new OTP.";
            unset($_SESSION['otp_data']);
        }
        // Verify OTP
        elseif ($submitted_otp === $otp_data['otp_code']) {
            $_SESSION['success'] = "Phone number verified successfully!";
            
            // Store verified phone in session for display.php
            $verified_phone = $otp_data['phone'];
            
            // In real application, mark OTP as used in database
            // Update user's phone verification status
            
            unset($_SESSION['otp_data']);
            unset($_SESSION['phone']);
            
            // Store verified phone and redirect to display.php
            $_SESSION['verified_phone'] = $verified_phone;
            header("Location: display.php");
            exit();
        } else {
            // Increment attempts
            $_SESSION['otp_data']['attempts']++;
            $remaining_attempts = 3 - $_SESSION['otp_data']['attempts'];
            $_SESSION['error'] = "Invalid OTP. $remaining_attempts attempts remaining.";
        }
    }
    header("Location: phoneverification.php");
    exit();
}?>